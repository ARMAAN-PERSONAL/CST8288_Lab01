//JUnit tests
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class EmployeeDirectorTest {

    private EmployeeDirector director;

    @Before
    public void setUp() {
        director = new EmployeeDirector(new FullTimeEmployeeBuilder());
    }

    @Test
    public void testEmployeeConstruction() {
        Employee employee = director.construct("001", "Alice", "IT", "Developer", 40, 75000);
        assertNotNull(employee);
        assertEquals("001", employee.getId());
        assertEquals("Alice", employee.getName());
        assertEquals("IT", employee.getDepartment());
        assertEquals("Developer", employee.getRole());
        assertEquals(40, employee.getWorkingHoursPerWeek());
        assertEquals(75000, employee.getSalary(), 0.01);
    }
}
