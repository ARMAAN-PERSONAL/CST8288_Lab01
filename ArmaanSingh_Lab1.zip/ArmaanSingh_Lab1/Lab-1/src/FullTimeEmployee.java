/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Abstract employee class, the OG for all employee types

public class FullTimeEmployee extends Employee {
    public FullTimeEmployee(String id, String name, String department, String role, int workingHoursPerWeek, double salary) {
        super(id, name, department, role, workingHoursPerWeek, salary);
    }

    @Override
    public void clockIn() {
        System.out.println(name + " (Full-Time) clocked in.");
    }

    @Override
    public void clockOut() {
        System.out.println(name + " (Full-Time) clocked out.");
    }

    @Override
    public void trackWorkHours() {
        System.out.println(name + " (Full-Time) worked for " + workingHoursPerWeek + " hours.");
    }
}
    // End of class
