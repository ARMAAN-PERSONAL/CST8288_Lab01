/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Singleton manager - only one manager to control the employee processes

import java.util.HashMap;
import java.util.Map;

public class EmployeeManager {
    private static EmployeeManager instance;
    private Map<String, Employee> employeeMap;

    private EmployeeManager() {
        employeeMap = new HashMap<>();
    }

    public static synchronized EmployeeManager getInstance() {
        if (instance == null) {
            instance = new EmployeeManager();
        }
        return instance;
    }

    public void addEmployee(Employee employee) {
        employeeMap.put(employee.id, employee);
    }

    public void removeEmployee(String employeeId) {
        employeeMap.remove(employeeId);
    }

    public Employee getEmployee(String employeeId) {
        return employeeMap.get(employeeId);
    }

    public void printAllEmployees() {
        employeeMap.values().forEach(System.out::println);
    }
}
    // End of class
