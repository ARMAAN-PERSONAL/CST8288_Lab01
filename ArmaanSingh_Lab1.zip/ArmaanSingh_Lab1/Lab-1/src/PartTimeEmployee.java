/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Abstract employee classfor Part-timers

public class PartTimeEmployee extends Employee {
    public PartTimeEmployee(String id, String name, String department, String role, int workingHoursPerWeek, double salary) {
        super(id, name, department, role, workingHoursPerWeek, salary);
    }

    @Override
    public void clockIn() {
        System.out.println(name + " (Part-Time) clocked in.");
    }

    @Override
    public void clockOut() {
        System.out.println(name + " (Part-Time) clocked out.");
    }

    @Override
    public void trackWorkHours() {
        System.out.println(name + " (Part-Time) worked for " + workingHoursPerWeek + " hours.");
    }
}
    // End of class
