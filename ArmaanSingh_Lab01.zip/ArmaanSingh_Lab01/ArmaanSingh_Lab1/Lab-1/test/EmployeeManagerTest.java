//Junit tests
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class EmployeeManagerTest {

    private EmployeeManager manager;

    @Before
    public void setUp() {
        manager = EmployeeManager.getInstance();
    }

    @Test
    public void testSingletonBehavior() {
        EmployeeManager manager2 = EmployeeManager.getInstance();
        assertSame(manager, manager2);
    }

    @Test
    public void testAddAndRetrieveEmployee() {
        Employee employee = new FullTimeEmployee("001", "Alice", "IT", "Developer", 40, 75000);
        manager.addEmployee(employee);
        assertEquals(employee, manager.getEmployee("001"));
    }

    @Test
    public void testRemoveEmployee() {
        Employee employee = new FullTimeEmployee("001", "Alice", "IT", "Developer", 40, 75000);
        manager.addEmployee(employee);
        manager.removeEmployee("001");
        assertNull(manager.getEmployee("001"));
    }
}
