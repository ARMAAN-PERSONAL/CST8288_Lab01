//JUnit tests
import static org.junit.Assert.*;
import org.junit.Test;

public class EmployeeFactoryTest {

    @Test
    public void testCreateFullTimeEmployee() {
        Employee employee = EmployeeFactory.createEmployee("fulltime", "001", "Alice", "IT", "Developer", 40, 75000);
        assertNotNull(employee);
        assertTrue(employee instanceof FullTimeEmployee);
    }

    @Test
    public void testCreatePartTimeEmployee() {
        Employee employee = EmployeeFactory.createEmployee("parttime", "002", "Bob", "HR", "Assistant", 20, 25000);
        assertNotNull(employee);
        assertTrue(employee instanceof PartTimeEmployee);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateUnknownEmployeeType() {
        EmployeeFactory.createEmployee("contract", "003", "Charlie", "Finance", "Analyst", 30, 50000);
    }
}
