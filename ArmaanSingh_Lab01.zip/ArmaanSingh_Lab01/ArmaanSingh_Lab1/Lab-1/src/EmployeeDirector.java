/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// EmployeeDirector - the manager, coordinating the builders to create employees

public class EmployeeDirector {
    private EmployeeBuilder builder;

    
/**
 * The EmployeeDirector class represents a core component of the Employee Management System (EMS).
 * This class is used in combination with design patterns such as Singleton, Builder, and Factory 
 * to demonstrate efficient object-oriented design and employee management.
 * <p>
 * Each employee has attributes such as ID, name, department, role, and salary.
 * Methods in this class handle operations like clocking in/out, tracking work hours, 
 * and managing employee details.
 * </p>
 */
public EmployeeDirector(EmployeeBuilder builder) {
        this.builder = builder;
    }

    public Employee construct(String id, String name, String department, String role, int workingHoursPerWeek, double salary) {
        return builder.setId(id)
                      .setName(name)
                      .setDepartment(department)
                      .setRole(role)
                      .setWorkingHoursPerWeek(workingHoursPerWeek)
                      .setSalary(salary)
                      .build();
    }
}
    // End of class
