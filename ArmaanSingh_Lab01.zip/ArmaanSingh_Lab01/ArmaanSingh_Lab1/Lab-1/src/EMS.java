  /*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Singleton manager - only one manager to rule them all

public class EMS {
    public static void main(String[] args) {
        EmployeeManager manager = EmployeeManager.getInstance();

        Employee emp1 = EmployeeFactory.createEmployee("fulltime", "001", "Armaan", "IT", "Developer", 40, 75000);
        Employee emp2 = EmployeeFactory.createEmployee("parttime", "002", "King", "HR", "Assistant", 20, 25000);

        manager.addEmployee(emp1);
        manager.addEmployee(emp2);

        emp1.clockIn();
        emp1.trackWorkHours();
        emp1.clockOut();

        emp2.clockIn();
        emp2.trackWorkHours();
        emp2.clockOut();

        manager.printAllEmployees();
    }
}
    // End of class
