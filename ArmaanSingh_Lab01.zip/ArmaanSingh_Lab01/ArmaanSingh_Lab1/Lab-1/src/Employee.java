/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Abstract employee class, the main for all employee types
public abstract class Employee {
    protected String id;
    protected String name;
    protected String department;
    protected String role;
    protected int workingHoursPerWeek;
    protected double salary;

    
/**
 * The Employee class represents a core component of the Employee Management System (EMS).
 * This class is used in combination with design patterns such as Singleton, Builder, and Factory 
 * to demonstrate efficient object-oriented design and employee management.
 * <p>
 * Each employee has attributes such as ID, name, department, role, and salary.
 * Methods in this class handle operations like clocking in/out, tracking work hours, 
 * and managing employee details.
 * </p>
 */
public Employee(String id, String name, String department, String role, int workingHoursPerWeek, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.role = role;
        this.workingHoursPerWeek = workingHoursPerWeek;
        this.salary = salary;
    }

    public abstract void clockIn();
    public abstract void clockOut();
    public abstract void trackWorkHours();

    
    /**
     * Retrieves a string value corresponding to the employee attribute.
     * This is typically a getter method that returns details like ID or name.
     *
     * @return the string value for the requested employee attribute.
     */
    public String getId() {
        return id;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setId(String id) {
        this.id = id;
    }

    
    /**
     * Retrieves a string value corresponding to the employee attribute.
     * This is typically a getter method that returns details like ID or name.
     *
     * @return the string value for the requested employee attribute.
     */
    public String getName() {
        return name;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setName(String name) {
        this.name = name;
    }

    
    /**
     * Retrieves a string value corresponding to the employee attribute.
     * This is typically a getter method that returns details like ID or name.
     *
     * @return the string value for the requested employee attribute.
     */
    public String getDepartment() {
        return department;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setDepartment(String department) {
        this.department = department;
    }

    
    /**
     * Retrieves a string value corresponding to the employee attribute.
     * This is typically a getter method that returns details like ID or name.
     *
     * @return the string value for the requested employee attribute.
     */
    public String getRole() {
        return role;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setRole(String role) {
        this.role = role;
    }

    
    /**
     * Retrieves an integer value, usually representing a numeric employee attribute.
     *
     * @return the integer value for the requested employee attribute.
     */
    public int getWorkingHoursPerWeek() {
        return workingHoursPerWeek;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setWorkingHoursPerWeek(int workingHoursPerWeek) {
        this.workingHoursPerWeek = workingHoursPerWeek;
    }

    
    /**
     * Retrieves a double value, typically representing a financial attribute such as salary.
     *
     * @return the double value for the requested employee attribute.
     */
    public double getSalary() {
        return salary;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    
    /**
     * Retrieves a string value corresponding to the employee attribute.
     * This is typically a getter method that returns details like ID or name.
     *
     * @return the string value for the requested employee attribute.
     */
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", department=" + department +
               ", role=" + role + ", workingHoursPerWeek=" + workingHoursPerWeek + ", salary=" + salary + "]";
    }
}
// End of class
