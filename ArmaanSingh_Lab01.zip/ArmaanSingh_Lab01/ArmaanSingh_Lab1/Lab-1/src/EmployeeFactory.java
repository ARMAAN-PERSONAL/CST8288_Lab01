/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Factory pattern - Getting the factory with the employee types

public class EmployeeFactory {
    public static Employee createEmployee(String type, String id, String name, String department, String role, int hours, double salary) {
        switch (type.toLowerCase()) {
            case "fulltime":
                EmployeeBuilder fullTimeBuilder = new FullTimeEmployeeBuilder();
                return new EmployeeDirector(fullTimeBuilder).construct(id, name, department, role, hours, salary);
            case "parttime":
                EmployeeBuilder partTimeBuilder = new PartTimeEmployeeBuilder();
                return new EmployeeDirector(partTimeBuilder).construct(id, name, department, role, hours, salary);
            default:
                throw new IllegalArgumentException("Unknown employee type: " + type);
        }
    }
}
    // End of class
