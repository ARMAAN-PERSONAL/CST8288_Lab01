/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Abstract employee class, the OG for all employee types

public class FullTimeEmployee extends Employee {
    
/**
 * The FullTimeEmployee class represents a core component of the Employee Management System (EMS).
 * This class is used in combination with design patterns such as Singleton, Builder, and Factory 
 * to demonstrate efficient object-oriented design and employee management.
 * <p>
 * Each employee has attributes such as ID, name, department, role, and salary.
 * Methods in this class handle operations like clocking in/out, tracking work hours, 
 * and managing employee details.
 * </p>
 */
public FullTimeEmployee(String id, String name, String department, String role, int workingHoursPerWeek, double salary) {
        super(id, name, department, role, workingHoursPerWeek, salary);
    }

    @Override
    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void clockIn() {
        System.out.println(name + " (Full-Time) clocked in.");
    }

    @Override
    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void clockOut() {
        System.out.println(name + " (Full-Time) clocked out.");
    }

    @Override
    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void trackWorkHours() {
        System.out.println(name + " (Full-Time) worked for " + workingHoursPerWeek + " hours.");
    }
}
    // End of class
