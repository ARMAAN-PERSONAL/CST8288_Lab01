/*
 * Lab 1 for CST8288 - Employee Management System
 * Created by Armaan Singh - Student ID: 041130409
 * This project implements Singleton, Builder, and Factory patterns.
 */

// Singleton manager - only one manager to control the employee processes

import java.util.HashMap;
import java.util.Map;

public class EmployeeManager {
    private static EmployeeManager instance;
    private Map<String, Employee> employeeMap;

    private EmployeeManager() {
        employeeMap = new HashMap<>();
    }

    public static synchronized EmployeeManager getInstance() {
        if (instance == null) {
            instance = new EmployeeManager();
        }
        return instance;
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void addEmployee(Employee employee) {
        employeeMap.put(employee.id, employee);
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void removeEmployee(String employeeId) {
        employeeMap.remove(employeeId);
    }

    public Employee getEmployee(String employeeId) {
        return employeeMap.get(employeeId);
    }

    
    /**
     * This method performs a key action for the employee object. 
     * Further details should be provided for the specific implementation.
     */
    public void printAllEmployees() {
        employeeMap.values().forEach(System.out::println);
    }
}
    // End of class
